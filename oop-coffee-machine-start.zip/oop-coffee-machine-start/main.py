from menu import Menu, MenuItem
from coffee_maker import CoffeeMaker
from money_machine import MoneyMachine
menu = Menu()
cash = MoneyMachine()
coffee = CoffeeMaker()

is_on = True
while is_on:
    options = menu.get_items()
    choice = input(f"what woukd you like?{options}")
    if choice == "off ":
        False
    elif choice == "report":
        cash.report()
        coffee.report()
    else:
        drink = menu.find_drink((choice))
        if coffee.is_resource_sufficient(drink) and cash.make_payment(drink.cost):
            coffee.make_coffee(drink)

